package OddNumber;

public class OddNumber {
    public static void main(String[] args) {
          for (int i = 1; i <= 500; i += 2) {
            System.out.println(i);
          }
        }
      }
