import java.util.Scanner;

public class CallingCost {
    public static void main(String[] args) {
        // Create a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the start time and end time
        System.out.println("Please input start hours: ");
        int startHours = scanner.nextInt();

        System.out.println("Please input start minutes: ");
        int startMinutes = scanner.nextInt();

        System.out.println("Please input start seconds: ");
        int startSeconds = scanner.nextInt();

        System.out.println("Please input end hours: ");
        int endHours = scanner.nextInt();

        System.out.println("Please input end minutes: ");
        int endMinutes = scanner.nextInt();

        System.out.println("Please input end seconds: ");
        int endSeconds = scanner.nextInt();

        // Calculate the call duration in seconds
        int callDurationSeconds = (endHours - startHours) * 3600 + (endMinutes - startMinutes) * 60 + (endSeconds - startSeconds);

        // Calculate the total number of minutes called
        double totalMinutes = callDurationSeconds / 60;

        // Calculate the total cost of the call
        double callCost = totalMinutes* 0.05;

        // Format the call duration
        String callDuration = formatTime(callDurationSeconds);

        // Display the results to the user
        System.out.println("Total call duration: " + callDuration);
        System.out.printf("Total cost of this call: %.4f $" , (callCost % 60));

        // Close the Scanner object
        scanner.close();
    }

    private static String formatTime(int seconds) {
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int remainingSeconds = seconds % 60;

        return hours + "h " + minutes + "mn " + remainingSeconds + "s";
    }
}
