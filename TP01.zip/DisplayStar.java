   public class DisplayStar {
        public static void main(String[] args) {
            System.out.println("Example: A " );
        System.out.println("*************************");
        System.out.println("*\t\t\t*");
        System.out.println("*\t\t\t*");
        System.out.println("*\t\t\t*");
        System.out.println("*\t\t\t*");
        System.out.println("*************************");
        System.out.println("\n");

        System.out.println("Example: B " );
        System.out.println("    *");
        System.out.println("   ***");
        System.out.println("  *****");
        System.out.println(" *******");
        System.out.println("*********");
        System.out.println("\n");

        System.out.println("Example: C " );
        System.out.println("*");
        System.out.println("***");
        System.out.println("*****");
        System.out.println("*******");
        System.out.println("*********");
        System.out.println("\n");

        System.out.println("Example: D " );
        System.out.println("        *");
        System.out.println("      ***");
        System.out.println("    *****");
        System.out.println("  *******");
        System.out.println("*********");
        System.out.println("\n");

        System.out.println("Example: E " );
        System.out.println("    *");
        System.out.println("  ***");
        System.out.println("*****");
        System.out.println("  ***");
        System.out.println("    *");
        System.out.println("\n");

        System.out.println("Example: F " );
        System.out.println("  *");
        System.out.println(" ***");
        System.out.println("*****");
        System.out.println(" ***");
        System.out.println("  *");
        System.out.println("\n");

        System.out.println("Example: G " );
        System.out.println("*****");
        System.out.println(" ***");
        System.out.println("  *");
        System.out.println(" ***");
        System.out.println("*****");
        System.out.println("\n");

        System.out.println("Example: H " );
        System.out.println("       *");
        System.out.println("   *       *");
        System.out.println("*             *");
        System.out.println("   *       *");
        System.out.println("       *");
        System.out.println("\n");
}
   }