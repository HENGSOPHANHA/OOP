public class PersonalInfo {
    public static void main(String[] args) {
        // Declare variables
        String name = "HENG SOPHANHA";
        int age = 19;
        float weight = 56.6f;
        String hobby = "Learning new things";

        // Print personal information
        System.out.println("My name is " + name + ".");
        System.out.println("I am " + age + " years old.");
        System.out.println("I weigh " + weight + " kilograms.");
        System.out.println("My hobby is " + hobby + ".");
    }
}
